function sv_plot end
function bode_plot end
function nyquist_plot end
function stabilization_plot end
function peaks_plot end
function waterfall_plot end
function theme_choice end